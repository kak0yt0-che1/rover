// Seeded random numbers: the same seed always gives the same failure, so a replay is exact.
(function () {
  const MR = (globalThis.MR = globalThis.MR || {});
  MR.rng = function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
})();
